#!/bin/bash

convert $(ls -1v symm*) odd.pdf
convert $(ls -1v asymm*) even.pdf
convert rand_layout_deltas.png rand_layout_deltas_hist.png rand_layout_deltas_barchart.png overviews.pdf
pdftk A=odd.pdf B=even.pdf shuffle A B output collated.pdf
pdfjam collated.pdf --nup 1x2 --outfile both.pdf
pdftk A=overviews.pdf B=both.pdf output final.pdf   